// contactPage.component.js
angular.module('myApp', [])
.component('contactPage', {
    templateUrl: 'contactPage.component.html',
    controller: ['$scope', function($scope) {
        // Controller logic goes here
    }]
});
