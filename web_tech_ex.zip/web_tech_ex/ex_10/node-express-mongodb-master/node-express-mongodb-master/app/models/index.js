const dbConfig = require("D:\html_css_js_learining\college\ex_10\node-express-mongodb-master\config\db.config.js");

const mongoose = require("mongoose");
mongoose.Promise = global.Promise;

const db = {};
db.mongoose = mongoose;
db.url = dbConfig.url;
db.tutorials = require("D:\html_css_js_learining\college\ex_10\node-express-mongodb-master\models\tutorial.model.js")(mongoose);

module.exports = db;
