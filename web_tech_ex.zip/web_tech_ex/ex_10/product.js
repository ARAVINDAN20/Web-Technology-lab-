console.log("hello i am aravind");
var name = "aravind";
console.log(name);
const mongoose = require("mongoose");
mongoose.connect("mongodb://localhost:27017/store").then (function(){
    console.log ("connected to the database")
})
const proSchema =new mongoose.Schema({pid:Number,pname:String},{collection:'product'});
const proModel = mongoose.model('product',proSchema)
console.log("Schema Mapped");
const http = require("http");
const hostname = "127.0.0.1";
const port = 2000;
const server=http.createServer(function(req,res){
    res.writeHead(200,{"Content-Type":"text/html"});
    //fetch the data from the mongodb collection
    proModel.find().then(function(product){
        res.write("Table Data")
        // res.write("<table border=1>")
        // res.write("<tr><th>PID</th><th>PNAME</th></tr>")
        // product.forEach(p => {
        //     res.write("<tr>")
        //     res.write(`<td>${p.pid}</td>`); 
        //     res.write(`<td>${p.pname}</td>`);  
        //     res.write("</tr>")
        // })
        // res.write("</table>")
        // res.end()

        // or another method
        var html="<table border='1'> <tr><th>Product ID</th><th>Name</th></tr>"
        for(let p of product){
            html+=`<tr><td>${p.pid}</td><td> ${p.pname} </td></tr>`
        }
        html += "</table>";
        res.end(html);

    })

});
server.listen(port,hostname,()=>{
    // console.log(`server is running at ${hostname}:${port}`)
    console.log(`server is running at http://127.0.0.1:${port}/`);


});















// const { ObjectId } = mongoose
// let userSchema = new mongoose.Schema({
//   username: String,
//   password: String,
// });
// let User = mongoose.model("User",userSchema)
// app.get("/signup", function(req, res){
//    const token= req.query.token;
//    if(!token || !isTokenValid(token)) return res.sendStatus(403);
//    //res.end();
//    res.render('signup');
// });
// function isTokenValid(token){
//   let validTokens=[];
//   for(i=0 ; i<5 ; i++){
//      var d = new Date()
//      d.setDate(d.getDate() - i);
//      validTokens.push(d.toISOString().substr(11,5));
//   }
//   return validTokens.includes(token);
// }
// app.post('/signup',upload.single('image'),function(req,res){
//   const token= req.body.token
//   if (!isTokenValid(token)){
//       return res.status(403).json({error:"Invalid Token"}).end()
//       }
//       const imagePath = `${__dirname}/public/images/${req.file.filename}`
//       const user = new User ({username : req.body.username ,password : req.body.password , imagePath })
//       user.save((err)=>{
//         if(err) throw err;
//           else{
//             fs.unlinkSync(`public/images/${req.file.filename}`)
//              res.redirect('/login')
//            }
//        });
// });




 