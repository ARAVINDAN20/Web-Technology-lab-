const http = require("http");
const fs = require("fs");
const url = require("url");
const path = require("path");
const mongoose = require("mongoose");
const queryString = require("querystring");

mongoose
  .connect("mongodb://localhost:27017/studentdb", { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.error("MongoDB Connection Error:", err));

const studentSchema = new mongoose.Schema({
  name: String,
  regno: Number,
  age: Number,
  year: Number,
  mentor: String,
  cgpa: Number
}, { collection: 'students' });
const Student = mongoose.model("students", studentSchema);

const navbar = () =>
  "<div style='background-color: #f0f0f0; padding: 10px 0; text-align: center;'><a href='/'>Home</a> |<a href='/create'>Create</a> |<a href='/read'>Read</a> |<a href='/update'>Update</a> | <a href='/delete'>Delete</a></div>";

const server = http.createServer((req, res) => {
  const { pathname } = url.parse(req.url, true);

  switch (pathname) {
    case "/":
      res.writeHead(200, { "Content-Type": "text/html" });
      res.end(
        `<html><body>${navbar()}<p>Welcome to the Home Page</p></body></html>`
      );
      break;
    case "/create":
      if (req.method === "GET") {
        serveFormPage(res, "create.html");
      } else if (req.method === "POST") {
        collectRequestData(req, (data) => {
          Student.create(data)
            .then(() => {
              res.writeHead(302, { Location: "/read" });
              res.end();
            })
            .catch((err) => {
              console.error("Error creating student:", err);
              res.writeHead(500);
              res.end("Error creating student");
            });
        });
      }
      break;
    case "/read":
      if (req.method === "GET") {
        Student.find()
          .then(function (students) {
            res.writeHead(200, { "Content-Type": "text/html" });
            let content = `${navbar()}<div style='text-align: center;'>`;
            content += "<h2>Student Records</h2>";
            content +=
              "<table style='border: 1px solid blue; cellspacing: 1px; width: 80%;'>";
            content +=
              "<tr><th>Name</th><th>Registration Number</th><th>Age</th><th>Year</th><th>Mentor</th><th>CGPA</th></tr>";

            students.forEach((student) => {
              content += "<tr>";
              content += `<td>${student.name}</td>`;
              content += `<td>${student.regno}</td>`;
              content += `<td>${student.age}</td>`;
              content += `<td>${student.year}</td>`;
              content += `<td>${student.mentor}</td>`;
              content += `<td>${student.cgpa}</td>`;
              content += "</tr>";
            });

            content += "</table></div>";
            res.end(content); 
          })
          .catch((err) => {
            console.error("Error fetching students:", err);
            res.writeHead(500);
            res.end("Error fetching students");
          });
      }
      break;
    case "/update":
      if (req.method === "GET") {
        serveFormPage(res, "update.html");
      } else if (req.method === "POST") {
        collectRequestData(req, (data) => {
          const { regno, ...updateData } = data;
          Student.findOneAndUpdate({ regno: regno }, updateData)
            .then(() => {
              res.writeHead(302, { Location: "/read" });
              res.end();
            })
            .catch((err) => {
              console.error("Error updating student:", err);
              res.writeHead(500);
              res.end("Error updating student");
            });
        });
      }
      break;
    case "/delete":
      if (req.method === "GET") {
        serveFormPage(res, "delete.html");
      } else if (req.method === "POST") {
        collectRequestData(req, (data) => {
          Student.findOneAndDelete({ regno: data.regno })
            .then(() => {
              res.writeHead(302, { Location: "/read" });
              res.end();
            })
            .catch((err) => {
              console.error("Error deleting student:", err);
              res.writeHead(500);
              res.end("Error deleting student");
            });
        });
      }
      break;
    default:
      res.writeHead(404);
      res.end("<html><body><p>Not Found</p></body></html>");
  }
});

function serveFormPage(res, pageName) {
  const filePath = path.join(__dirname, pageName);
  fs.readFile(filePath, (err, data) => {
    if (err) {
      console.error(`Error reading ${filePath}:`, err);
      res.writeHead(500);
      res.end("Server Error: Unable to read form page.");
      return;
    }
    res.writeHead(200, { "Content-Type": "text/html" });
    res.end(`<html><body>${navbar()}${data}</body></html>`);
  });
}

function collectRequestData(request, callback) {
  let data = "";
  request.on("data", (chunk) => (data += chunk));
  request.on("end", () => {
    callback(queryString.parse(data));
  });
}

server.listen(9200, () => {
  console.log("Server running on http://localhost:9200");
});
