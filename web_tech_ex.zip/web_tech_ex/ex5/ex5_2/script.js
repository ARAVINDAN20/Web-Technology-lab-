function calculateEMI() {
    const principal = parseFloat(document.getElementById('loan-amount').value);
    const tenure = parseFloat(document.getElementById('loan-tenure').value);
    const rate = parseFloat(document.getElementById('interest-rate').value) / (12 * 100);

    const numerator = principal * rate * Math.pow(1 + rate, tenure);
    const denominator = Math.pow(1 + rate, tenure) - 1;

    const emi = numerator / denominator;
    document.getElementById('emi-result').textContent = `Monthly EMI: $${emi.toFixed(3)}`;
}

function clearFields() {
    document.getElementById('loan-amount').value = '';
    document.getElementById('loan-tenure').value = '';
    document.getElementById('interest-rate').value = '';
    document.getElementById('emi-result').textContent = 'Monthly EMI: ';
}
