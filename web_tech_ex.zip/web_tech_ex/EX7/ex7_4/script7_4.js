
        function blinkHeading() {
            $('#heading').fadeOut(1000, function () {
                $(this).fadeIn(1000, blinkHeading);
            });
        }
        blinkHeading();

        $('#bgColorDropdown').change(function () {
            const selectedColor = $(this).val();
            $('body').css('background-color', selectedColor);
        });

        $('.menu .accordion-toggle').click(function () {
            $(this).toggleClass('open');
            $(this).next('.accordion-content').slideToggle().toggleClass('show'); //Slide toggle
        });