function performCalculation(operator) {
    const firstNum = parseFloat(document.getElementById('firstNumber').value);
    const secondNum = parseFloat(document.getElementById('secondNumber').value);

    let result;
    switch (operator) {
        case '+':
            result = firstNum + secondNum;
            break;
        case '-':
            result = firstNum - secondNum;
            break;
        case '*':
            result = firstNum * secondNum;
            break;
        case '/':
            result = firstNum / secondNum;
            break;
    }

    document.getElementById('answer').value = result;
}

function clearFields() {
    document.getElementById('firstNumber').value = '';
    document.getElementById('secondNumber').value = '';
    document.getElementById('answer').value = '';
}
