// app.js
var app = angular.module('myApp', ['ngRoute']);

app.config(function($routeProvider) {
    $routeProvider
        .when('/', {
            templateUrl: 'personal-details.html',
            controller: 'PersonalDetailsController'
        })
        .when('/academic', {
            templateUrl: 'academic-details.html',
            controller: 'AcademicDetailsController'
        })
        // Add routes for other pages
        .otherwise({
            redirectTo: '/'
        });
});
