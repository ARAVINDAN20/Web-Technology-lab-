function add() {
    var num1 = parseFloat($("#num1").val());
    var num2 = parseFloat($("#num2").val());
    var result = num1 + num2;
    $("#result").text(result);
    $("#resultTextarea").val(result);
  }

  function sub() {
    var num1 = parseFloat($("#num1").val());
    var num2 = parseFloat($("#num2").val());
    var result = num1 - num2;
    $("#result").text(result);
    $("#resultTextarea").val(result);
  }

  function mul() {
    var num1 = parseFloat($("#num1").val());
    var num2 = parseFloat($("#num2").val());
    var result = num1 * num2;
    $("#result").text(result);
    $("#resultTextarea").val(result);
  }

  function div() {
    var num1 = parseFloat($("#num1").val());
    var num2 = parseFloat($("#num2").val());
    var result = num1 / num2;
    $("#result").text(result);
    $("#resultTextarea").val(result);
  }

  function clear() {
    $("#num1").val("");
    $("#num2").val("");
    $("#result").text("0");
    $("#resultTextarea").val("0");
  }
  
  // Initialize the functionality by triggering the 'Clear' button
  $(document).ready(function() {
    $("#clear").click();
  });