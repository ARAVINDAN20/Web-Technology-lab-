console.log("Hello, I am Aravind.");

// Importing required modules
const mongoose = require("mongoose");
const http = require("http");

// Connecting to MongoDB database
mongoose.connect("mongodb://localhost:27017/studentdb", { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("Connected to the database");
  })
  .catch((error) => {
    console.error("Failed to connect to the database:", error);
  });

// Defining schema for students collection
const studentSchema = new mongoose.Schema({
  name: String,
  regno: Number,
  age: Number,
  year: Number,
  mentor: String,
  cgpa: Number
}, { collection: 'students' });

// Creating model for students collection
const Student = mongoose.model('students', studentSchema);

// Creating HTTP server
const hostname = "127.0.0.1";
const port = 2000;
const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "text/html" });

  // Fetching data from MongoDB collection
  Student.find().then(function (students) {
    // Rendering table data
    let output = "<h2>Student Data</h2><table border='1' style='border-color: red;'><tr><th>Name</th><th>Reg No</th><th>Age</th><th>Year</th><th>Mentor</th><th>CGPA</th></tr>";
    for (let student of students) {
      output += `<tr><td>${student.name}</td><td>${student.regno}</td><td>${student.age}</td><td>${student.year}</td><td>${student.mentor}</td><td>${student.cgpa}</td></tr>`;
    }
    output += "</table>";
    res.end(output);
  }).catch(function (error) {
    console.error("Error fetching students:", error);
    res.end("Error fetching students");
  });
});

// Starting the server
server.listen(port, hostname, () => {
  console.log(`Server is running at http://127.0.0.1:${port}/`);
});
