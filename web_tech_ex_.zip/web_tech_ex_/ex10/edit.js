// Importing required modules
const mongoose = require("mongoose");
const http = require("http");
const fs = require('fs');
const { parse } = require('querystring');

// Connecting to MongoDB database
mongoose.connect("mongodb://localhost:27017/studentdb", { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log("Connected to the database");
  })
  .catch((error) => {
    console.error("Failed to connect to the database:", error);
  });

// Defining schema for students collection
const studentSchema = new mongoose.Schema({
  name: String,
  regno: Number,
  age: Number,
  year: Number,
  mentor: String,
  cgpa: Number
}, { collection: 'students' });

// Creating model for students collection
const Student = mongoose.model('students', studentSchema);

// Function to insert a new student into the database
const insertStudent = (studentData, res) => {
  Student.findOne({ regno: studentData.regno }) // Check if student with same registration number exists
    .then(existingStudent => {
      if (existingStudent) {
        console.log(`Student with registration number ${studentData.regno} already exists`);
        res.writeHead(302, { 'Location': '/' });
        res.end();
      } else {
        new Student(studentData).save() // Insert new student
          .then(() => {
            console.log('Student added successfully');
            res.writeHead(302, { 'Location': '/' });
            res.end();
          })
          .catch(error => {
            console.error('Error saving student:', error);
            res.writeHead(500);
            res.end('Error saving student');
          });
      }
    });
};

// Function to delete a student from the database
const deleteStudent = (regno, res) => {
  Student.findOneAndDelete({ regno: regno }) // Find and delete student by registration number
    .then(() => {
      console.log('Student deleted successfully');
      res.writeHead(302, { 'Location': '/' });
      res.end();
    })
    .catch(error => {
      console.error('Error deleting student:', error);
      res.writeHead(500);
      res.end('Error deleting student');
    });
};

// Function to update a student in the database
const updateStudent = (regno, studentData, res) => {
  Student.findOneAndUpdate({ regno: regno }, studentData) // Find and update student by registration number
    .then(() => {
      console.log('Student updated successfully');
      res.writeHead(302, { 'Location': '/' });
      res.end();
    })
    .catch(error => {
      console.error('Error updating student:', error);
      res.writeHead(500);
      res.end('Error updating student');
    });
};

// Creating HTTP server
const hostname = "127.0.0.1";
const port = 5000;
const server = http.createServer((req, res) => {
  const path = req.url;
  if (path === '/') {
    fs.readFile('index.html', (err, data) => {
      if (err) {
        res.writeHead(404);
        res.end('Error: Page Not Found');
      } else {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write(data);
        return res.end();
      }
    });
  } else if (path === '/students' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const studentData = parse(body);
      if (!studentData.regno) {
        console.error('Registration number is missing');
        res.writeHead(400);
        res.end('Registration number is missing');
        return;
      }
      insertStudent(studentData, res);
    });
  } else if (path.startsWith('/delete/') && req.method === 'GET') {
    const regno = path.split('/')[2]; // Extract registration number from URL
    deleteStudent(regno, res);
  } else if (path.startsWith('/edit/') && req.method === 'POST') {
    const regno = path.split('/')[2]; // Extract registration number from URL
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const studentData = parse(body);
      updateStudent(regno, studentData, res);
    });
  } else {
    res.writeHead(404);
    res.end('Error: Page Not Found');
  }
});

// Starting the server
server.listen(port, hostname, () => {
  console.log(`Server is running at http://${hostname}:${port}/`);
});
